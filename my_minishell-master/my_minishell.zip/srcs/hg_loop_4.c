/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hg_loop_4.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hgoncalv <hgoncalv@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/22 15:17:04 by hgoncalv          #+#    #+#             */
/*   Updated: 2023/01/07 02:11:29 by hgoncalv         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"

void	pipe_get_return_from_child(int status)
{
	if (WTERMSIG(status) == SIGINT)
		_shell()->exit_code = 130;
	else if (WTERMSIG(status) == SIGQUIT)
		_shell()->exit_code = 131;
	else
		_shell()->exit_code = status / 256;
}
