/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hgoncalv <hgoncalv@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/22 15:19:50 by hgoncalv          #+#    #+#             */
/*   Updated: 2023/01/08 19:36:09 by hgoncalv         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"

void	ft_handler(int signum)
{
	pid_t	pid;
	int		status;

	pid = waitpid(-1, &status, 0);
	if (signum == SIGINT)
	{
		if (pid == -1)
		{
			_shell()->exit_code = 130;
			write(1, "\n", 1);
			rl_replace_line("", 0);
			rl_on_new_line();
			rl_redisplay();
		}
		else
			write(1, "\n", 1);
	}
	if (signum == SIGQUIT)
	{
		if (pid == -1)
			_shell()->exit_code = 131;
		write(1, "\n", 1);
	}
}

void	signal4main(void)
{
	signal(SIGINT, ft_handler);
	signal(SIGQUIT, SIG_IGN);
}

void	signal_default(void)
{
	signal(SIGINT, SIG_DFL);
	signal(SIGQUIT, SIG_DFL);
}

int	init_remove_qt(void)
{
	t_cmd	*ptr;
	int		i;

	ptr = _shell()->head;
	while (ptr)
	{
		i = 0;
		while (ptr->args[i])
		{
			parse_clean(&(ptr->args[i]));
			i++;
		}
		ptr = ptr->next;
	}
	return (1);
}

void	minishell(void)
{
	char	*line;
	char	**matrix;

	while (!_shell()->exit)
	{
		signal4main();
		line = readline("minishell> ");
		if (line == NULL)
		{
			_shell()->exit_code = 0;
			printf("exit\n");
			return ;
		}
		remove_start_end_spaces(&line);
		add_history(line);
		line = ft_var_expansion(line);
		matrix = line_to_matrix(&line);
		if (!matrix)
		{
			minishell_clean(&line);
			continue ;
		}
		_shell()->p2matrix = &matrix;
		add_cmds(matrix);
		init_remove_qt();
		if (_shell()->head && _shell()->head->args[0])
			pipe_commands(_shell()->head);
		minishell_clean(&line);
	}
	minishell_clean(&line);
}

int	main(int ac, char **av, char **ev)
{
	char	*shlvl;

	(void)ac;
	(void)av;
	if (ac != 1)
		return (0);
	init_shell(ev);
	_shell()->exit_code = 0;
	shlvl = ft_itoa(ft_atoi(getenv("SHLVL")) + 1);
	ft_setenv("SHLVL", shlvl, 1);
	free(shlvl);
	minishell();
	close_shell();
	return (_shell()->exit_code);
}
